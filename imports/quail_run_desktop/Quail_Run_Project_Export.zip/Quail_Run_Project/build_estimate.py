import csv, json

with open('data/quail_run_takeoff.csv') as f:
    takeoff = list(csv.DictReader(f))

with open('pricing.config.json') as f:
    pricing = json.load(f)

with open('data/meadow_creek_category_multipliers.json') as f:
    multipliers = json.load(f)

total = 0

for row in takeoff:
    code = row['Code']
    qty = float(row['Quantity'])
    category = row['Category']
    cost = qty * pricing[category][code] * multipliers[category]
    total += cost

print(f'Total Estimate: ${total:,.2f}')
