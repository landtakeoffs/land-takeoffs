# Bid Assumptions
20 disturbed acres
35 pads
Wetland buffer present
