# Executive Summary
Estimated Total: $799,343.75
